To execute the parser test suite, run `python2 run_tests.py`, with the working
directory set to this directory.
